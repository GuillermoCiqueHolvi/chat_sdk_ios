//
// ChatSDK.h
// ChatSDK
//
// Created by Zendesk on 05/11/2018.
//
// Copyright © 2018 Zendesk. All rights reserved.
//
// By downloading or using the Zendesk Mobile SDK, You agree to the Zendesk Master
// Subscription Agreement https://www.zendesk.com/company/customers-partners/#master-subscription-agreement
// and Application Developer and API License
//
// Agreement https://www.zendesk.com/company/customers-partners/#application-developer-api-license-agreement and
// acknowledge that such terms govern Your use of and access to the Mobile SDK.


#import <UIKit/UIKit.h>

//! Project version number for ChatSDK.
FOUNDATION_EXPORT double ChatSDKVersionNumber;

//! Project version string for ChatSDK.
FOUNDATION_EXPORT const unsigned char ChatSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ChatSDK/PublicHeader.h>


